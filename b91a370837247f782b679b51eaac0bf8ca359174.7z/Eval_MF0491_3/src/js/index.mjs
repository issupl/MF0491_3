sessionStorage.setItem('variable', 0);



document.querySelector('#suma').addEventListener('click',()=>{

    let valor = sessionStorage.getItem('variable');
    let result = parseInt(valor,10) + 1;
    let elSpan = document.getElementsByTagName('span')[0];
    
    sessionStorage.setItem('variable',result);
    elSpan.innerHTML = result;
})
